# Django Portfolio (with Blog, Services, Testimonials, Resume, REST API)
## Quick start
1. Create venv & install:
   ```bash
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Local env:
   ```bash
   cp .env.example .env
   python manage.py makemigrations
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py loaddata sample_data.json
   python manage.py runserver
   ```
3. Visit http://127.0.0.1:8000/

### API
- `/api/projects/`
- `/api/blog/`

### Heroku
- Use `Procfile` and `runtime.txt`. Add `heroku-postgresql`, set `ALLOWED_HOSTS`, `SECRET_KEY`, etc.
