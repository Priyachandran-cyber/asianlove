from django.db import models
from django.utils.text import slugify

class Timestamped(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        abstract = True

class Skill(Timestamped):
    name = models.CharField(max_length=100, unique=True)
    level = models.PositiveSmallIntegerField(default=75, help_text="0-100 proficiency")
    def __str__(self): return self.name

class Experience(Timestamped):
    company = models.CharField(max_length=150)
    role = models.CharField(max_length=150)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    description = models.TextField(blank=True)
    def __str__(self): return f"{self.role} @ {self.company}"

class Project(Timestamped):
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    summary = models.TextField()
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to="projects/", blank=True, null=True)
    skills = models.ManyToManyField(Skill, blank=True)
    url = models.URLField(blank=True)
    repo = models.URLField(blank=True)
    is_featured = models.BooleanField(default=False)
    def save(self, *args, **kwargs):
        if not self.slug: self.slug = slugify(self.title)
        super().save(*args, **kwargs)
    def __str__(self): return self.title

class ContactMessage(Timestamped):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    def __str__(self): return f"Message from {self.name}"

class Tag(Timestamped):
    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(max_length=60, unique=True, blank=True)
    def save(self, *args, **kwargs):
        if not self.slug: self.slug = slugify(self.name)
        return super().save(*args, **kwargs)
    def __str__(self): return self.name

class BlogPost(Timestamped):
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    summary = models.TextField()
    content = models.TextField()
    cover_image = models.ImageField(upload_to="blog/", blank=True, null=True)
    is_published = models.BooleanField(default=True)
    published_at = models.DateTimeField(null=True, blank=True)
    tags = models.ManyToManyField(Tag, blank=True)
    def save(self, *args, **kwargs):
        from django.utils import timezone
        if not self.slug: self.slug = slugify(self.title)
        if self.is_published and not self.published_at: self.published_at = timezone.now()
        return super().save(*args, **kwargs)
    class Meta:
        ordering = ["-published_at", "-created_at"]
    def __str__(self): return self.title

class Service(Timestamped):
    title = models.CharField(max_length=120)
    description = models.TextField()
    price_note = models.CharField(max_length=120, blank=True)
    def __str__(self): return self.title

class Testimonial(Timestamped):
    name = models.CharField(max_length=120)
    role = models.CharField(max_length=120, blank=True)
    company = models.CharField(max_length=120, blank=True)
    quote = models.TextField()
    avatar = models.ImageField(upload_to="testimonials/", blank=True, null=True)
    def __str__(self): return f"{self.name} — {self.company or self.role}"

class ResumeFile(Timestamped):
    file = models.FileField(upload_to="resume/")
    def __str__(self): return self.file.name
