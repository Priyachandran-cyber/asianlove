from rest_framework import serializers
from .models import Project, BlogPost, Tag

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ["name", "slug"]

class ProjectSerializer(serializers.ModelSerializer):
    skills = serializers.StringRelatedField(many=True)
    class Meta:
        model = Project
        fields = ["title", "slug", "summary", "description", "image", "url", "repo", "is_featured", "skills"]

class BlogPostSerializer(serializers.ModelSerializer):
    tags = TagSerializer(many=True)
    class Meta:
        model = BlogPost
        fields = ["title", "slug", "summary", "content", "cover_image", "published_at", "tags"]
