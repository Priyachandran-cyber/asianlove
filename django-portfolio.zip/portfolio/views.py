from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.http import HttpResponseRedirect
from .models import Project, Skill, Experience, ContactMessage, BlogPost, Service, Testimonial, ResumeFile

def home(request):
    context = {
        "featured": Project.objects.filter(is_featured=True)[:3],
        "skills": Skill.objects.order_by("-level")[:12],
        "experiences": Experience.objects.order_by("-start_date")[:5],
    }
    return render(request, "home.html", context)

def project_list(request):
    projects = Project.objects.order_by("-created_at")
    return render(request, "projects.html", {"projects": projects})

def project_detail(request, slug):
    project = get_object_or_404(Project, slug=slug)
    return render(request, "project_detail.html", {"project": project})

def contact(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        message = request.POST.get("message")
        if not (name and email and message):
            messages.error(request, "Please fill all fields.")
        else:
            ContactMessage.objects.create(name=name, email=email, message=message)
            try:
                send_mail(
                    subject=f"Portfolio contact from {name}",
                    message=message,
                    from_email=None,
                    recipient_list=[request.get_host()],
                )
            except Exception:
                pass
            messages.success(request, "Thanks! I'll get back to you soon.")
            return redirect("portfolio:contact")
    return render(request, "contact.html")

def blog_list(request):
    posts = BlogPost.objects.filter(is_published=True)
    return render(request, "blog_list.html", {"posts": posts})

def blog_detail(request, slug):
    post = get_object_or_404(BlogPost, slug=slug, is_published=True)
    return render(request, "blog_detail.html", {"post": post})

def services(request):
    return render(request, "services.html", {"services": Service.objects.all()})

def testimonials(request):
    return render(request, "testimonials.html", {"items": Testimonial.objects.all()})

def resume_download(request):
    latest = ResumeFile.objects.order_by("-created_at").first()
    if latest and latest.file:
        return HttpResponseRedirect(latest.file.url)
    messages.error(request, "Resume not uploaded yet.")
    return redirect("portfolio:home")
